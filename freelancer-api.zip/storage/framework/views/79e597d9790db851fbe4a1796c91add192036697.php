

<?php $__env->startSection('content'); ?>
    <div class="body"> 
        <h4 class="head">
           <?php echo e($data["subject"]); ?>


        </h4>

        <section class="content">
            <p>
                Hi   <?php echo e($data["main"]["firstname"]); ?>

            </p>
                <p>
                    Thanks for choosing the Freelancer, we’re happy you’ve chosen to be part of us!  
   <br/><br/>
    Search  various types of services around your location with ease — welcome! If there’s anything you need, we’ll be here every step of the way.
</p>

        </section>
     
<div class="extra">
   <div class="btn_container">
        <a href="<?php echo e($data['link']); ?>" target="_blank" class="btn_text">
        Confirm Email Address
    </a>
   </div>
    <div class="token">
    here is your token  <b><?php echo e($data["token"]); ?></b>
    </div>
    <div class="link">
     here is your link <a href="<?php echo e($data['link']); ?>" target="_blank"><?php echo e($data['link']); ?></a>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\Backend\freelancer-api\resources\views/emails/welcome.blade.php ENDPATH**/ ?>